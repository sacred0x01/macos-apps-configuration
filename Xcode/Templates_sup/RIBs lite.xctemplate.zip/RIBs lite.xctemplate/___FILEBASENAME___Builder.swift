//___FILEHEADER___

import RIBsCore

final class ___VARIABLE_productName___Builder {
    func build(appComponent: AppComponent) -> ViewController {
        let vc = StoryboardScene.___VARIABLE_productName___.___VARIABLE_productName___ViewController.instantiate()
        let router = ___VARIABLE_productName___Router(appComponent: appComponent, viewController: vc)
        let interactor = ___VARIABLE_productName___Interactor(presenter: vc, router: router)
        vc.interactor = interactor
        
        return vc
    }
}
