//___FILEHEADER___

import Foundation
import RIBsCore

protocol ___VARIABLE_productName___Routing: ViewRouting {
    var viewController: ___VARIABLE_productName___Controllable { get }
}

final class ___VARIABLE_productName___Router {
    let appComponent: AppComponent
    unowned let viewController: ___VARIABLE_productName___Controllable
    
    init(appComponent: AppComponent, viewController: ___VARIABLE_productName___Controllable) {
        self.appComponent = appComponent
        self.viewController = viewController
    }
}

extension ___VARIABLE_productName___Router: ___VARIABLE_productName___Routing {}
